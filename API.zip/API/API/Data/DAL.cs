﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.InMemory;
using API.Interfaces;

namespace API.Data
{
    public class DAL
    {
        private static MyContext context;
        public class CartItem : ICartItem
        {

            public int ID { get; set; }
            public int ProductID { get; set; }
            public decimal Price { get; set; }
            public int Quantity { get; set; }
            public decimal Discount { get; set; }

            public static List<CartItem> PopulateCartItems()
            {
                List<CartItem> cartItems = new List<CartItem>();


                cartItems.Add(new CartItem
                {
                    ProductID = 1,
                    Price = 25,
                    Quantity = 25,
                    Discount = 0,
                });

                cartItems.Add(new CartItem
                {
                    ProductID = 2,
                    Price = 100,
                    Quantity = 12,
                    Discount = 20,
                });

                cartItems.Add(new CartItem
                {
                    ProductID = 45,
                    Price = 25,
                    Quantity = 25,
                    Discount = 0,
                });

                cartItems.Add(new CartItem
                {
                    ProductID = 23,
                    Price = 99.99M,
                    Quantity = 1,
                    Discount = 20,
                });
                cartItems.Add(new CartItem
                {
                    ProductID = 1,
                    Price = 25,
                    Quantity = 50,
                    Discount = 0,
                });

                cartItems.Add(new CartItem
                {
                    ProductID = 5,
                    Price = 34,
                    Quantity = 12,
                    Discount = 0,
                });

                return cartItems;
            }

            public Array GetAllCartItems()
            {
                Array cartItems;
                var optionsBuilder = new DbContextOptionsBuilder<MyContext>();
                optionsBuilder.UseInMemoryDatabase("Shop");
                optionsBuilder.EnableSensitiveDataLogging(false);

                //context = new MyContext(optionsBuilder.Options);

                if (context == null)
                {
                    context = new MyContext(optionsBuilder.Options);

                    foreach (CartItem cartItem in PopulateCartItems())
                    {
                        context.CartItems.Add(cartItem);
                    }


                    context.SaveChanges();


                    return context.CartItems.ToArray();

                }
                cartItems = context.CartItems.Local.ToArray();

                return cartItems;
            }


            public Array Get()
            {
                Array cartItems;
                cartItems = GetAllCartItems();
                return cartItems;
            }

            public object Get(int ID)
            {
                if (context==null)
                {
                    GetAllCartItems();
                }


                var cartItems = (context.CartItems
                         .Where(s => s.ID == ID)
                         .FirstOrDefault());

                return cartItems;
            }

            public bool Add(ICartItem cartItem)
            {
                if (context == null)
                {
                    GetAllCartItems();
                }

                CartItem newCartItem = new CartItem();
                try
                {
                    //Setting the new ID to new applicant
                    newCartItem.ID = context.CartItems.Local.Count + 1;
                    newCartItem.ProductID = cartItem.ProductID;
                    newCartItem.Price = cartItem.Price;
                    newCartItem.Quantity = cartItem.Quantity;
                    newCartItem.Discount = cartItem.Discount;
                    context.CartItems.Add(newCartItem);
                    context.SaveChanges();
                }
                catch (Exception ex)
                {

                    throw;
                }
                return true;
            }

            public bool Update(int ID, ICartItem cartItem)
            {
                if (context == null)
                {
                    GetAllCartItems();
                }

                var result = context.CartItems.SingleOrDefault(a => a.ID == ID);
                if (result != null)
                {
                    result.ProductID = cartItem.ProductID;
                    result.Price = cartItem.Price;
                    result.Quantity = cartItem.Quantity;
                    result.Discount = cartItem.Discount;
                    context.SaveChanges();

                    return true;
                }
                return false;
            }

            public bool Delete(int ID)
            {
                if (context == null)
                {
                    GetAllCartItems();
                }

                CartItem result = context.CartItems.SingleOrDefault(a => a.ID == ID);
                if (result != null)
                {
                    context.CartItems.Remove(result);
                    context.SaveChanges();

                    return true;
                }
                return false;
            }

        }

        private class MyContext : DbContext
        {
            public MyContext(DbContextOptions<MyContext> options)
            : base(options)
            {

            }
            public virtual DbSet<CartItem> CartItems { get; set; }

        }


      
    }
}
