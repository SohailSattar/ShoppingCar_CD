﻿using API.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static API.Data.DAL;

namespace API.Models
{
    public class CartItem : ICartItem
    {
        public int ID { get; set; }
        public int ProductID { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public decimal Discount { get; set; }

        public bool Add(ICartItem cartItem)
        {
            throw new NotImplementedException();
        }

        public bool Delete(int ID)
        {
            throw new NotImplementedException();
        }

        public Array Get()
        {
            throw new NotImplementedException();
        }

        public object Get(int id)
        {
            throw new NotImplementedException();
        }

        public bool Update(int ID, ICartItem cartItem)
        {
            throw new NotImplementedException();
        }
    }
}
