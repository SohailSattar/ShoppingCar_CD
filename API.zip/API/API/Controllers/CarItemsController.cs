﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using API.Interfaces;
using API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace API.Controllers
{
    [Authorize]
    [Route("api/cart-items")]
    [ApiController]
    public class CarItemsController : ControllerBase
    {
        private ICartItem _cartItem;

        public CarItemsController(ICartItem cartItem)
        {
            _cartItem = cartItem;
        }


        // GET: api/cart-items
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var res = _cartItem.Get();
                return Ok(res);
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid Request");
            }
        }

        // GET api/cart-items/5
        [HttpGet("{id}")]
        [Authorize]
        public IActionResult Get(int id)
        {
            try
            {
                var res = _cartItem.Get(id);
                return Ok(res);
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid Request");
            }
        }

        // POST api/<CarItemsController>
        [HttpPost]
        public IActionResult Post([FromBody] CartItem cartItem)
        {
            try
            {
                var res = _cartItem.Add(cartItem);
                return Ok("Record Added");
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid Request");
            }
        }

        // PUT api/<CarItemsController>/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] CartItem cartItem)
        {
            try
            {
                var res = _cartItem.Update(id, cartItem);
                return Ok("Record Updated");
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid Request");
            }
        }

        // DELETE api/<CarItemsController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                var res = _cartItem.Delete(id);
                return Ok("Record Deleted");
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid Request");
            }
        }
    }
}
