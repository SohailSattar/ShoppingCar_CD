﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Interfaces
{
    public interface ICartItem
    {
        int ID { get; set; }
        int ProductID { get; set; }
        decimal Price { get; set; }
        int Quantity { get; set; }
        decimal Discount { get; set; }

        public Array Get();
        public object Get(int id);
        bool Add(ICartItem cartItem);
        public bool Update(int ID, ICartItem cartItem);
        public bool Delete(int ID);
    }
}
